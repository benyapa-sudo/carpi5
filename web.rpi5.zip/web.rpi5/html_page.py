# html_page.py
HTML_PAGE = """<!DOCTYPE html>
<html>
<head>
<title>Robot Control Center</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">

<style>

body{
font-family:'Segoe UI',Arial;
margin:20px;
background:#f4f4f9;
}

h1{
text-align:center;
color:#333;
margin-bottom:30px;
}

h2{
margin-top:0;
color:#555;
border-bottom:2px solid #ddd;
padding-bottom:10px;
font-size:1.2rem;
}

.main-container{
display:flex;
flex-wrap:wrap;
justify-content:center;
gap:20px;
}

/* CAMERA */

.camera-section{
display:flex;
flex-direction:column;
align-items:center;
}

.cam-feed{
border:4px solid #333;
border-radius:8px;
background:#000;
width:320px;
height:240px;
box-shadow:0 4px 10px rgba(0,0,0,0.3);
}

.ai-controls{
margin-top:15px;
}

.btn-ai{
padding:10px 20px;
margin:5px;
cursor:pointer;
color:white;
border:none;
border-radius:6px;
font-weight:bold;
}

.btn-on{background:#28a745;}
.btn-off{background:#dc3545;}
.btn-led-on{background:#007bff;}
.btn-led-off{background:#6c757d;}

/* PANEL */

.control-panel{
background:white;
padding:20px;
border-radius:10px;
box-shadow:0 2px 5px rgba(0,0,0,0.1);
width:300px;
}

.slider{width:100%;}

.slider-container{
margin-bottom:15px;
}

/* D-PAD */

.dpad{
display:grid;
grid-template-columns:80px 80px 80px;
grid-template-rows:80px 80px 80px;
gap:10px;
justify-content:center;
margin-top:20px;
}

.dpad button{
font-size:18px;
font-weight:bold;
border:none;
border-radius:10px;
background:#e3e8ef;
box-shadow:0 3px 6px rgba(0,0,0,0.2);
cursor:pointer;
}

.dpad button:active{
transform:scale(0.95);
}

.up{grid-column:2;grid-row:1;background:#cce5ff;}
.left{grid-column:1;grid-row:2;background:#cce5ff;}
.center{grid-column:2;grid-row:2;background:#ffb3b3;}
.right{grid-column:3;grid-row:2;background:#cce5ff;}
.down{grid-column:2;grid-row:3;background:#cce5ff;}

.encoder-box{
margin-top:20px;
padding-top:15px;
border-top:1px solid #eee;
}

.enc-btn{
padding:6px 10px;
margin-top:5px;
cursor:pointer;
}

</style>
</head>

<body>

<h1>Robot Control Center</h1>

<div class="main-container">

<div class="camera-section">

<img src="/video" class="cam-feed">

<div class="ai-controls">
<button class="btn-ai btn-on" onclick="toggleAI(true)">AI ON</button>
<button class="btn-ai btn-off" onclick="toggleAI(false)">AI OFF</button>
</div>

<div class="ai-controls">
<button class="btn-ai btn-led-on" onclick="toggleLED(2,1)">LED ON</button>
<button class="btn-ai btn-led-off" onclick="toggleLED(2,0)">LED OFF</button>
</div>

</div>


<div class="control-panel">

<h2>Motors</h2>

<div class="slider-container">
Speed Left: <span id="pwmLval">150</span>
<input type="range" id="pwmL" min="0" max="255" value="150" class="slider">
</div>

<div class="slider-container">
Speed Right: <span id="pwmRval">150</span>
<input type="range" id="pwmR" min="0" max="255" value="150" class="slider">
</div>

<div class="slider-container">
Step Time (ms)
<input type="number" id="stepTime" value="250">
</div>

<div class="dpad">

<button class="up"
onclick="stepMove('f')"
onmousedown="startMove('f')" onmouseup="stopMove()"
ontouchstart="startMove('f')" ontouchend="stopMove()">?</button>

<button class="left"
onclick="stepMove('l')"
onmousedown="startMove('l')" onmouseup="stopMove()"
ontouchstart="startMove('l')" ontouchend="stopMove()">?</button>

<button class="center" onclick="forceStop()">STOP</button>

<button class="right"
onclick="stepMove('r')"
onmousedown="startMove('r')" onmouseup="stopMove()"
ontouchstart="startMove('r')" ontouchend="stopMove()">?</button>

<button class="down"
onclick="stepMove('b')"
onmousedown="startMove('b')" onmouseup="stopMove()"
ontouchstart="startMove('b')" ontouchend="stopMove()">?</button>

</div>

</div>
<div class="control-panel">

<h2>Servos</h2>

<div class="slider-container">
Servo 0: <span id="s0val">90</span>
<input type="range" id="s0" min="0" max="180" value="90" class="slider">
</div>

<div class="slider-container">
Servo 1: <span id="s1val">90</span>
<input type="range" id="s1" min="0" max="180" value="90" class="slider">
</div>

<div class="slider-container">
Servo 2: <span id="s2val">90</span>
<input type="range" id="s2" min="0" max="180" value="90" class="slider">
</div>

<div class="encoder-box">

<h2>Encoders</h2>

L: <span id="encL">0</span><br>
R: <span id="encR">0</span><br>

Distance L: <span id="distL">0</span> m<br>
Distance R: <span id="distR">0</span> m

<br>

<button class="enc-btn" onclick="readEnc()">Read</button>
<button class="enc-btn" onclick="resetEnc()">Reset</button>

</div>

</div>

</div>

<script>

const pwmL=document.getElementById('pwmL')
const pwmR=document.getElementById('pwmR')

const pwmLval=document.getElementById('pwmLval')
const pwmRval=document.getElementById('pwmRval')

pwmL.oninput=()=>pwmLval.innerText=pwmL.value
pwmR.oninput=()=>pwmRval.innerText=pwmR.value

let isHolding=false

function calc(dir){

let l=parseInt(pwmL.value)
let r=parseInt(pwmR.value)

if(dir==='b'){l=-l;r=-r}
if(dir==='l'){l=-l}
if(dir==='r'){r=-r}

return {l,r}

}

function stepMove(dir){

if(isHolding)return

let {l,r}=calc(dir)

fetch(`/move_once?l=${l}&r=${r}&t=${stepTime.value}`)

}

async function startMove(dir){

if(isHolding)return

isHolding=true

let {l,r}=calc(dir)

while(isHolding){

await fetch(`/motor?l=${l}&r=${r}`)

}

}

function stopMove(){

isHolding=false

fetch('/motor?l=0&r=0')

setTimeout(()=>fetch('/motor?l=0&r=0'),50)

}

function forceStop(){

isHolding=false
fetch('/motor?l=0&r=0')

}

const s0=document.getElementById('s0')
const s1=document.getElementById('s1')
const s2=document.getElementById('s2')

const s0val=document.getElementById('s0val')
const s1val=document.getElementById('s1val')
const s2val=document.getElementById('s2val')

s0.oninput=()=>{s0val.innerText=s0.value;fetch(`/servo?id=0&angle=${s0.value}`)}
s1.oninput=()=>{s1val.innerText=s1.value;fetch(`/servo?id=1&angle=${s1.value}`)}
s2.oninput=()=>{s2val.innerText=s2.value;fetch(`/servo?id=2&angle=${s2.value}`)}

function readEnc(){

fetch('/encoders')
.then(r=>r.json())
.then(d=>{

document.getElementById('encL').innerText=d.left
document.getElementById('encR').innerText=d.right

document.getElementById('distL').innerText=d.distance_l
document.getElementById('distR').innerText=d.distance_r

})

}

function resetEnc(){fetch('/reset')}
function toggleAI(state){fetch('/toggle_ai?enabled='+state)}
function toggleLED(pin,state){fetch(`/led?pin=${pin}&state=${state}`)}

</script>

</body>
</html>
"""